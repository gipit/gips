<?xml version="1.0" encoding="UTF-8"?>
<eop:Mask xmlns:eop="http://www.opengis.net/eop/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:gml="http://www.opengis.net/gml/3.2" gml:id="S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B03_MSIL1C">
  <gml:name>MSK_DETFOO pixels mask from data-strip S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B03_MSIL1C</gml:name>
  <gml:boundedBy>
    <gml:Envelope srsName="urn:ogc:def:crs:EPSG:8.7:32618">
      <gml:lowerCorner>555814.9308511893 4690200 0</gml:lowerCorner>
      <gml:upperCorner>609780 4800000 0</gml:upperCorner>
    </gml:Envelope>
  </gml:boundedBy>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B03-01-0">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.0_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">555814.930851189303212 4690200.0 0 558807.716264464426786 4703358.193515559658408 0 562503.441727299476042 4719716.887028660625219 0 566174.614967798232101 4736079.473776775412261 0 569808.895623964257538 4752446.615906794555485 0 573527.539801607606933 4768790.821462561376393 0 577264.887124339933507 4785133.164988814853132 0 580610.353389295050874 4800000.0 0 608115.709479762241244 4800000.0 0 607384.159598120488226 4796740.946259319782257 0 603691.392975470400415 4780373.73947920370847 0 599992.087078910088167 4764010.984123362228274 0 596318.3796164940577 4747644.426569456234574 0 592630.053558912593871 4731283.318358319811523 0 588936.33569703088142 4714917.658234652131796 0 585236.406607617740519 4698550.610447942279279 0 583332.109306129277684 4690200.0 0 555814.930851189303212 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B03-02-1">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.1_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">581527.985851316363551 4690200.0 0 583522.169720658566803 4698963.388702486641705 0 587205.586511337663978 4715325.891491779126227 0 590894.369918749318458 4731686.242978760972619 0 594595.64745821012184 4748044.958637009374797 0 598277.056628058664501 4764409.225075379014015 0 601968.97768671263475 4780776.005135236307979 0 605664.569721909589134 4797142.066064532846212 0 606306.951701242127456 4800000.0 0 609780 4800000 0 609780.0 4695354.655349288135767 0 609509.531929069547914 4694162.562815862707794 0 608609.460877959849313 4690200.0 0 581527.985851316363551 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B03-03-2">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.2_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">607185.546386114670895 4690200.0 0 608124.063774372218177 4694324.961202844977379 0 609780.0 4701598.752815838903189 0 609780 4690200 0 607185.546386114670895 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
</eop:Mask>
