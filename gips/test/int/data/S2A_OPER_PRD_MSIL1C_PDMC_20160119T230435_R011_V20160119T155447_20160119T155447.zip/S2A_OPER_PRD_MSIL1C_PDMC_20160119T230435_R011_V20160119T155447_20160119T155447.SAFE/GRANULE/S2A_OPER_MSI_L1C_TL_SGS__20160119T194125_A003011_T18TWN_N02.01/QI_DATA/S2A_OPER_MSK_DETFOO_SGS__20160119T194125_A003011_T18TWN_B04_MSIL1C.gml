<?xml version="1.0" encoding="UTF-8"?>
<eop:Mask xmlns:eop="http://www.opengis.net/eop/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:gml="http://www.opengis.net/gml/3.2" gml:id="S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B04_MSIL1C">
  <gml:name>MSK_DETFOO pixels mask from data-strip S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B04_MSIL1C</gml:name>
  <gml:boundedBy>
    <gml:Envelope srsName="urn:ogc:def:crs:EPSG:8.7:32618">
      <gml:lowerCorner>555840.2373724215 4690200 0</gml:lowerCorner>
      <gml:upperCorner>609780 4800000 0</gml:upperCorner>
    </gml:Envelope>
  </gml:boundedBy>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B04-01-0">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.0_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">555840.237372421543114 4690200.0 0 558835.766085622715764 4703353.245705291628838 0 562524.444343879353255 4719713.751952624879777 0 566198.346261129714549 4736077.684357156977057 0 569836.869151590159163 4752446.695768708363175 0 573569.294160755467601 4768787.03442457318306 0 577282.409035258926451 4785133.185180293396115 0 580624.463174532866105 4800000.0 0 608125.230520092067309 4800000.0 0 607384.998308091890067 4796714.48985777515918 0 603696.432983570266515 4780347.469412605278194 0 600020.122525616781786 4763980.342747857794166 0 596332.44120812730398 4747616.474528351798654 0 592640.922501460881904 4731254.546568508259952 0 588944.587248683557846 4714887.919323900714517 0 585250.177131174481474 4698519.44588290899992 0 583351.513994397944771 4690200.0 0 555840.237372421543114 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B04-02-1">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.1_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">581482.817288028309122 4690200.0 0 583479.504648140165955 4698965.705294938758016 0 587158.891224747989327 4715326.163883315399289 0 590849.395893254783005 4731684.862964674830437 0 594537.972320973873138 4748048.29534416552633 0 598231.286645571468398 4764411.468890993855894 0 601937.903012409573421 4780773.719972588121891 0 605625.543507837108336 4797142.30785899143666 0 606266.317749095615 4800000.0 0 609780 4800000 0 609780.0 4695497.02794786170125 0 609483.000613946933299 4694186.221708026714623 0 608576.378143965499476 4690200.0 0 581482.817288028309122 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B04-03-2">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.2_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">607201.930550120538101 4690200.0 0 608139.027322721201926 4694314.626833719201386 0 609780.0 4701535.114476857706904 0 609780 4690200 0 607201.930550120538101 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
</eop:Mask>
