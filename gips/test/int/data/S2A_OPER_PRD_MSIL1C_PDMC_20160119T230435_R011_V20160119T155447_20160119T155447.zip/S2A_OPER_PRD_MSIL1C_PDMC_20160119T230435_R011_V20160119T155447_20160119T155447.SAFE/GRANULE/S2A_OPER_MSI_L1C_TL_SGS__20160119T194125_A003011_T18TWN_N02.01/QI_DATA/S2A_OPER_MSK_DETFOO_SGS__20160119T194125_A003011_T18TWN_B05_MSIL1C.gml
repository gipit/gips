<?xml version="1.0" encoding="UTF-8"?>
<eop:Mask xmlns:eop="http://www.opengis.net/eop/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:gml="http://www.opengis.net/gml/3.2" gml:id="S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B05_MSIL1C">
  <gml:name>MSK_DETFOO pixels mask from data-strip S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B05_MSIL1C</gml:name>
  <gml:boundedBy>
    <gml:Envelope srsName="urn:ogc:def:crs:EPSG:8.7:32618">
      <gml:lowerCorner>555860.7832932373 4690200 0</gml:lowerCorner>
      <gml:upperCorner>609780 4800000 0</gml:upperCorner>
    </gml:Envelope>
  </gml:boundedBy>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B05-01-0">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.0_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">555860.783293237327598 4690200.0 0 558851.636849770788103 4703342.333770674653351 0 562543.663025625282899 4719702.410254846327007 0 566217.431678689084947 4736067.650350030511618 0 569857.133039493463002 4752436.836171488277614 0 573585.996133792214096 4768776.807005077600479 0 577308.10003803903237 4785120.862545973621309 0 580648.752883897861466 4800000.0 0 608132.229855641839094 4800000.0 0 607389.251996334292926 4796691.977501649409533 0 603705.44237676076591 4780323.804426574148238 0 600018.93137556524016 4763958.654944370500743 0 596334.911428990541026 4747594.436586868017912 0 592642.561815747176297 4731232.880275179632008 0 588946.341774619184434 4714865.256928429938853 0 585247.577742531779222 4698497.539381795562804 0 583355.954292230657302 4690200.0 0 555860.783293237327598 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B05-02-1">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.1_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">581465.56893712526653 4690200.0 0 583462.837073569069616 4698964.860907204449177 0 587138.152562450501136 4715325.606262147426605 0 590820.130546705564484 4731686.558388491161168 0 594525.884001568891108 4748045.354360589757562 0 598219.683523505926132 4764408.535249863751233 0 601911.173479809309356 4780774.706524405628443 0 605600.193864006316289 4797141.801078422926366 0 606241.484392336336896 4800000.0 0 609780 4800000 0 609780.0 4695591.511177421547472 0 609464.799324156483635 4694198.586625898256898 0 608554.863460771739483 4690200.0 0 581465.56893712526653 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B05-03-2">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.2_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">607214.593633448588662 4690200.0 0 608150.196774607873522 4694312.241287212818861 0 609780.0 4701475.816489532589912 0 609780 4690200 0 607214.593633448588662 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
</eop:Mask>
