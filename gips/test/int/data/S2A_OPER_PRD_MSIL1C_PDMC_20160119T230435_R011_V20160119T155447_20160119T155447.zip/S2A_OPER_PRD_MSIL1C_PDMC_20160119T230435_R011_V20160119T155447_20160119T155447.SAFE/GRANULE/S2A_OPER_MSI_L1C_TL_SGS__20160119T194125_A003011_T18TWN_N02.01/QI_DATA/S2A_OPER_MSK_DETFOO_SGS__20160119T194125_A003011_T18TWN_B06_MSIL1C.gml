<?xml version="1.0" encoding="UTF-8"?>
<eop:Mask xmlns:eop="http://www.opengis.net/eop/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:gml="http://www.opengis.net/gml/3.2" gml:id="S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B06_MSIL1C">
  <gml:name>MSK_DETFOO pixels mask from data-strip S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B06_MSIL1C</gml:name>
  <gml:boundedBy>
    <gml:Envelope srsName="urn:ogc:def:crs:EPSG:8.7:32618">
      <gml:lowerCorner>555871.7263248313 4690200 0</gml:lowerCorner>
      <gml:upperCorner>609780 4800000 0</gml:upperCorner>
    </gml:Envelope>
  </gml:boundedBy>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B06-01-0">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.0_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">555871.726324831251986 4690200.0 0 558864.578520050738007 4703342.937015144154429 0 562557.533668990130536 4719703.760921279899776 0 566234.234467101981863 4736069.056477914564312 0 569869.302017879905179 4752440.073762018233538 0 573586.252073593554087 4768782.292412301525474 0 577322.609474849537946 4785122.026968621648848 0 580667.457747975597158 4800000.0 0 608146.652429399313405 4800000.0 0 607402.363223264110275 4796677.758802768774331 0 603713.717188538052142 4780310.81983199995011 0 600013.16408180387225 4763949.43094651773572 0 596340.838424209388904 4747582.44471151009202 0 592653.200280277524143 4731219.6411192426458 0 588953.967351631144993 4714852.235676876269281 0 585253.950091995997354 4698483.939444225281477 0 583364.556257845251821 4690200.0 0 555871.726324831251986 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B06-02-1">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.1_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">581438.652420134749264 4690200.0 0 583432.070164790493436 4698954.139882592484355 0 587110.831613505724818 4715313.443396929651499 0 590799.034614811767824 4731672.959468979388475 0 594503.142062308848836 4748031.877339976839721 0 598190.82433751039207 4764396.610101295635104 0 601879.430598773877136 4780763.184081415645778 0 605569.767056634882465 4797130.591874230653048 0 606214.69408906204626 4800000.0 0 609780 4800000 0 609780.0 4695684.560030989348888 0 609443.629422289552167 4694199.196602422744036 0 608534.121820642612875 4690200.0 0 581438.652420134749264 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B06-03-2">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.2_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">607221.639451306080446 4690200.0 0 608152.146392833557911 4694288.753878247924149 0 609780.0 4701440.082709652371705 0 609780 4690200 0 607221.639451306080446 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
</eop:Mask>
