<?xml version="1.0" encoding="UTF-8"?>
<eop:Mask xmlns:eop="http://www.opengis.net/eop/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:gml="http://www.opengis.net/gml/3.2" gml:id="S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B07_MSIL1C">
  <gml:name>MSK_DETFOO pixels mask from data-strip S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B07_MSIL1C</gml:name>
  <gml:boundedBy>
    <gml:Envelope srsName="urn:ogc:def:crs:EPSG:8.7:32618">
      <gml:lowerCorner>555882.676974058 4690200 0</gml:lowerCorner>
      <gml:upperCorner>609780 4800000 0</gml:upperCorner>
    </gml:Envelope>
  </gml:boundedBy>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B07-01-0">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.0_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">555882.67697405803483 4690200.0 0 558873.373874732060358 4703322.376841636374593 0 562562.81408460799139 4719685.388729774393141 0 566240.604426446603611 4736050.765757362358272 0 569876.937463332898915 4752422.558466838672757 0 573597.112913485965692 4768762.873649288900197 0 577318.767038201447576 4785106.711048467084765 0 580670.908905697171576 4800000.0 0 608150.881803726661019 4800000.0 0 607396.695444467011839 4796647.883331765420735 0 603704.615163741400465 4780281.937111342325807 0 600017.386459028813988 4763916.500704751349986 0 596342.148155750706792 4747550.723150516860187 0 592653.423117436934263 4731187.698438750579953 0 588953.316631727269851 4714820.343643487431109 0 585255.382357725990005 4698450.426946514286101 0 583372.733411710592918 4690200.0 0 555882.67697405803483 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B07-02-1">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.1_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">581408.552855208865367 4690200.0 0 583402.292569771641865 4698958.331189083866775 0 587083.509526907000691 4715316.665827049873769 0 590782.003757302649319 4731674.238959754817188 0 594468.278681028168648 4748037.573927787132561 0 598156.36177784204483 4764402.035023885779083 0 601859.764825897989795 4780764.904299406334758 0 605551.410907559096813 4797132.536767805926502 0 606194.880325549514964 4800000.0 0 609780 4800000 0 609780.0 4695788.500697514042258 0 609423.542432028800249 4694215.490338779054582 0 608510.553885819390416 4690200.0 0 581408.552855208865367 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B07-03-2">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.2_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">607228.83426142076496 4690200.0 0 608158.219080881797709 4694280.755143265239894 0 609780.0 4701410.424183513969183 0 609780 4690200 0 607228.83426142076496 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
</eop:Mask>
