<?xml version="1.0" encoding="UTF-8"?>
<eop:Mask xmlns:eop="http://www.opengis.net/eop/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:gml="http://www.opengis.net/gml/3.2" gml:id="S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B09_MSIL1C">
  <gml:name>MSK_DETFOO pixels mask from data-strip S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B09_MSIL1C</gml:name>
  <gml:boundedBy>
    <gml:Envelope srsName="urn:ogc:def:crs:EPSG:8.7:32618">
      <gml:lowerCorner>555910.7129798834 4690200 0</gml:lowerCorner>
      <gml:upperCorner>609780 4800000 0</gml:upperCorner>
    </gml:Envelope>
  </gml:boundedBy>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B09-01-0">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.0_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">555910.712979883421212 4690200.0 0 558894.205826698220335 4703282.970670694485307 0 562582.890593777177855 4719647.359627871774137 0 566260.430507816723548 4736014.162657357752323 0 569903.491366109228693 4752389.49245167337358 0 573623.569715351215564 4768728.350126361474395 0 577347.747054434032179 4785068.82909004483372 0 580699.126294335117564 4800000.0 0 608104.620977643528022 4800000.0 0 607337.180161629454233 4796580.984019740484655 0 603655.63573299231939 4780213.743393497541547 0 599963.501333339489065 4763851.027346474118531 0 596288.747882358147763 4747484.578903823159635 0 592593.74442421970889 4731120.004465943202376 0 588895.101623431663029 4714751.537169335409999 0 585194.95027470390778 4698381.458238392136991 0 583328.026921641547233 4690200.0 0 555910.712979883421212 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B09-02-1">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.1_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">581325.108410616056062 4690200.0 0 583320.941771304467693 4698977.777137104421854 0 586996.503733617253602 4715334.625709655694664 0 590686.244924416183494 4731694.080394918099046 0 594389.922060876851901 4748054.903252043761313 0 598082.583925823681056 4764418.125723435543478 0 601775.914977381122299 4780783.888945951126516 0 605460.779123890097253 4797151.653721147216856 0 606100.888053003698587 4800000.0 0 609780 4800000 0 609780.0 4696356.243392606265843 0 609310.769358296180144 4694282.360878131352365 0 608383.509028612170368 4690200.0 0 581325.108410616056062 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B09-03-2">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.2_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">607244.499509659130126 4690200.0 0 608176.739042196888477 4694294.007182534784079 0 609780.0 4701337.796540222130716 0 609780 4690200 0 607244.499509659130126 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
</eop:Mask>
