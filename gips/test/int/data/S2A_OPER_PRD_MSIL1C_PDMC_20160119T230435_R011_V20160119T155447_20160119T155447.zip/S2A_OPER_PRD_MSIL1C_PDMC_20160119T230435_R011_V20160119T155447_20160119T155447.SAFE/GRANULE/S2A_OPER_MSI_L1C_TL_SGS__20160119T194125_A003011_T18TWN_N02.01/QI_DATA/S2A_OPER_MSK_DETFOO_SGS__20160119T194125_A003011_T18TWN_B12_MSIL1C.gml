<?xml version="1.0" encoding="UTF-8"?>
<eop:Mask xmlns:eop="http://www.opengis.net/eop/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:gml="http://www.opengis.net/gml/3.2" gml:id="S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B12_MSIL1C">
  <gml:name>MSK_DETFOO pixels mask from data-strip S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B12_MSIL1C</gml:name>
  <gml:boundedBy>
    <gml:Envelope srsName="urn:ogc:def:crs:EPSG:8.7:32618">
      <gml:lowerCorner>556200.4777591724 4690200 0</gml:lowerCorner>
      <gml:upperCorner>609780 4800000 0</gml:upperCorner>
    </gml:Envelope>
  </gml:boundedBy>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B12-01-0">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.0_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">556200.477759172441438 4690200.0 0 559177.315824451623484 4703272.032653504982591 0 562869.664292425150052 4719634.825725322589278 0 566540.199973209528252 4736002.351655210368335 0 570182.59266159881372 4752375.113004157319665 0 573913.230136377504095 4768712.657165029086173 0 577630.718201301409863 4785055.540195325389504 0 580969.447223688825034 4800000.0 0 608442.514233995229006 4800000.0 0 607671.60817394789774 4796579.010946212336421 0 603987.799359203781933 4780212.415162672288716 0 600306.80402974167373 4763846.590158628299832 0 596623.376574738300405 4747481.950470877811313 0 592928.576115614618175 4731118.81751792691648 0 589236.452815809869207 4714749.184380576945841 0 585532.142372622038238 4698380.852243671193719 0 583667.141567034879699 4690200.0 0 556200.477759172441438 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B12-02-1">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.1_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">581679.179881575400941 4690200.0 0 583663.933964464464225 4698916.261339468881488 0 587338.593096876284108 4715275.529725753702223 0 591032.426038198173046 4731634.659480417147279 0 594727.425773608614691 4747995.443930211476982 0 598422.33313862606883 4764358.780835255980492 0 602124.250655750045553 4780723.775066133588552 0 605815.382972227758728 4797090.820684596896172 0 606467.340446886140853 4800000.0 0 609780 4800000 0 609780.0 4694635.322478050366044 0 609680.177768153720535 4694194.901370530948043 0 608772.279223816236481 4690200.0 0 581679.179881575400941 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B12-03-2">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.2_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">607523.718930864008144 4690200.0 0 608436.656144432607107 4694217.369946951977909 0 609780.0 4700117.021653839387 0 609780 4690200 0 607523.718930864008144 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
</eop:Mask>
