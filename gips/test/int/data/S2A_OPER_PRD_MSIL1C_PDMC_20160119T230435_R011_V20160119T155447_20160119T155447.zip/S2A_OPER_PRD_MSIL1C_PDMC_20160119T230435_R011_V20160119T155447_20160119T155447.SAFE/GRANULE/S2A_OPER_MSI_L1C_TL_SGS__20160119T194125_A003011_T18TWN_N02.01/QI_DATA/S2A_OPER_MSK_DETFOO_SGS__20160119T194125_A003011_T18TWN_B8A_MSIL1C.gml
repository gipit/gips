<?xml version="1.0" encoding="UTF-8"?>
<eop:Mask xmlns:eop="http://www.opengis.net/eop/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:gml="http://www.opengis.net/gml/3.2" gml:id="S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B8A_MSIL1C">
  <gml:name>MSK_DETFOO pixels mask from data-strip S2A_OPER_MSK_DETFOO_SGS__20160119T194125_A003011_T18TWN_B8A_MSIL1C</gml:name>
  <gml:boundedBy>
    <gml:Envelope srsName="urn:ogc:def:crs:EPSG:8.7:32618">
      <gml:lowerCorner>555892.8848182474 4690200 0</gml:lowerCorner>
      <gml:upperCorner>609780 4800000 0</gml:upperCorner>
    </gml:Envelope>
  </gml:boundedBy>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B8A-01-0">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.0_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">555892.884818247403018 4690200.0 0 558878.91851377277635 4703318.645379312336445 0 562570.884045048966072 4719681.479056481271982 0 566245.085798045271076 4736047.565975815057755 0 569887.369662634679116 4752419.4975166907534 0 573616.383775561233051 4768757.539555599913001 0 577327.681656632805243 4785102.892276889644563 0 580675.618335055420175 4800000.0 0 608153.995677832746878 4800000.0 0 607394.545570045360364 4796629.668281971476972 0 603707.991999793914147 4780263.535008900798857 0 600030.513252840726636 4763896.315340812318027 0 596346.754558404092677 4747532.095962753519416 0 592652.202855261857621 4731169.554088900797069 0 588955.724549164646305 4714801.684761592186987 0 585254.866183636942878 4698432.084575423039496 0 583379.04379002971109 4690200.0 0 555892.884818247403018 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B8A-02-1">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.1_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">581380.056851878762245 4690200.0 0 583375.820973580586724 4698965.148203711956739 0 587053.883320809691213 4715324.3394187213853 0 590747.052371875965036 4731683.107480354607105 0 594438.186009424040094 4748044.517743068747222 0 598132.423873535823077 4764407.728407462127507 0 601837.148120372788981 4780772.226447191089392 0 605528.657912632916123 4797139.005041648633778 0 606169.617551747825928 4800000.0 0 609780 4800000 0 609780.0 4695882.510228756815195 0 609406.693483115290292 4694233.64752441085875 0 608489.294334932463244 4690200.0 0 581380.056851878762245 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
  <eop:maskMembers>
    <eop:MaskFeature gml:id="detector_footprint-B8A-03-2">
      <eop:maskType codeSpace="urn:gs2:S2PDGS:maskType">DETECTOR_FOOTPRINT</eop:maskType>
      <eop:extentOf>
        <gml:Polygon gml:id="DETECTOR_FOOTPRINT.2_Polygon">
          <gml:exterior>
            <gml:LinearRing>
              <gml:posList srsDimension="3">607233.074951576418243 4690200.0 0 608160.333108652499504 4694276.35002725571394 0 609780.0 4701392.753351042978466 0 609780 4690200 0 607233.074951576418243 4690200.0 0</gml:posList>
            </gml:LinearRing>
          </gml:exterior>
        </gml:Polygon>
      </eop:extentOf>
    </eop:MaskFeature>
  </eop:maskMembers>
</eop:Mask>
