<?xml version="1.0" encoding="UTF-8"?>
<eop:Mask xmlns:eop="http://www.opengis.net/eop/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:gml="http://www.opengis.net/gml/3.2" gml:id="S2A_OPER_MSK_SATURA_SGS__20160119T194125_A003011_T19TCG_B05_MSIL1C">
  <gml:name>MSK_SATURA pixels mask from data-strip S2A_OPER_MSK_SATURA_SGS__20160119T194125_A003011_T19TCG_B05_MSIL1C</gml:name>
</eop:Mask>
